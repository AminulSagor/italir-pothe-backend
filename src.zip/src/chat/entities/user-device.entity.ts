import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
  Unique,
} from 'typeorm';
import { User } from '../../users/entities/user.entity';
import { DeviceAppState, DevicePlatform } from '../enums/chat.enums';

@Entity('user_devices')
@Index('IDX_user_devices_userId', ['userId'])
@Index('IDX_user_devices_deviceId', ['deviceId'])
@Unique('UQ_user_devices_user_device', ['userId', 'deviceId'])
export class UserDevice {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'uuid' })
  userId: string;

  @ManyToOne(() => User, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'userId' })
  user: User;

  @Column({ type: 'varchar', length: 120 })
  deviceId: string;

  @Column({
    type: 'enum',
    enum: DevicePlatform,
  })
  platform: DevicePlatform;

  @Column({
    type: 'enum',
    enum: DeviceAppState,
    default: DeviceAppState.FOREGROUND,
  })
  appState: DeviceAppState;

  @Column({ type: 'varchar', length: 512, nullable: true })
  fcmToken: string | null;

  @Column({ type: 'timestamptz', nullable: true })
  lastActiveAt: Date | null;

  @CreateDateColumn({ type: 'timestamptz' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamptz' })
  updatedAt: Date;
}
