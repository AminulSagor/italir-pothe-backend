import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';

import { User } from 'src/users/entities/user.entity';
import { Course } from '../../courses/entities/course.entity';
import {
  CourseAccessType,
  CourseEnrollmentStatus,
} from '../types/course-commerce.type';
import { CoursePurchaseOrder } from './course-purchase-order.entity';
import { AdminCourseAccessGrant } from './admin-course-access-grant.entity';

@Entity('course_enrollments')
@Index(['userId', 'courseId'], {
  unique: true,
})
export class CourseEnrollment {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Index()
  @Column({ type: 'uuid' })
  userId: string;

  @Index()
  @Column({ type: 'uuid', nullable: true })
  courseId: string | null;

  @Index()
  @Column({ type: 'uuid', nullable: true })
  orderId: string | null;

  @Column({
    type: 'enum',
    enum: CourseEnrollmentStatus,
    default: CourseEnrollmentStatus.ACTIVE,
  })
  status: CourseEnrollmentStatus;

  @Column({
    type: 'enum',
    enum: CourseAccessType,
    default: CourseAccessType.LIFETIME,
  })
  accessType: CourseAccessType;

  @Column({ type: 'timestamptz' })
  enrolledAt: Date;

  @Column({
    type: 'timestamptz',
    nullable: true,
  })
  expiresAt: Date | null;

  @Column({
    type: 'timestamptz',
    nullable: true,
  })
  refundedAt: Date | null;

  @Column({
    type: 'timestamptz',
    nullable: true,
  })
  lastAccessedAt: Date | null;

  @CreateDateColumn({
    type: 'timestamptz',
  })
  createdAt: Date;

  @UpdateDateColumn({
    type: 'timestamptz',
  })
  updatedAt: Date;

  @ManyToOne(() => User, {
    createForeignKeyConstraints: false,
  })
  @JoinColumn({
    name: 'userId',
  })
  user: User | null;

  @ManyToOne(() => Course, {
    nullable: true,
    onDelete: 'SET NULL',
  })
  @JoinColumn({ name: 'courseId' })
  course: Course | null;

  @ManyToOne(() => CoursePurchaseOrder, {
    nullable: true,
    onDelete: 'RESTRICT',
  })
  @JoinColumn({ name: 'orderId' })
  order: CoursePurchaseOrder | null;

  @OneToMany(() => AdminCourseAccessGrant, (grant) => grant.enrollment)
  externalGrants: AdminCourseAccessGrant[];
}
