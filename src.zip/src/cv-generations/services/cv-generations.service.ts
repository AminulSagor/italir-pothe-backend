import {
  BadRequestException,
  ForbiddenException,
  HttpException,
  Injectable,
  Logger,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

import { FilePurpose } from 'src/files/entities/file.entity';
import {
  FileRequestUser,
  FilesService,
} from 'src/files/services/files.service';
import { CvTemplatesService } from 'src/cv-templates/services/cv-templates.service';

import { CreateCvGenerationDto } from '../dto/create-cv-generation.dto';
import { CvDataDto } from '../dto/cv-data.dto';
import { CvGeneration } from '../entities/cv-generation.entity';
import {
  CvGenerationMode,
  CvGenerationStatus,
} from '../enums/cv-generation.enum';
import {
  CvImageGenerationService,
  CvReferenceImage,
} from './cv-image-generation.service';
import { CvPromptService } from './cv-prompt.service';

@Injectable()
export class CvGenerationsService {
  private readonly logger = new Logger(CvGenerationsService.name);

  constructor(
    @InjectRepository(CvGeneration)
    private readonly cvGenerationRepository: Repository<CvGeneration>,

    private readonly cvTemplatesService: CvTemplatesService,

    private readonly filesService: FilesService,

    private readonly cvPromptService: CvPromptService,

    private readonly cvImageGenerationService: CvImageGenerationService,
  ) {}

  async create(dto: CreateCvGenerationDto, currentUser: FileRequestUser) {
    this.validateMode(dto);

    if (dto.profilePhotoFileId) {
      await this.assertOwnedProfilePhoto(
        dto.profilePhotoFileId,
        currentUser.id,
      );
    }

    if (dto.mode === CvGenerationMode.TEMPLATE && dto.templateId) {
      await this.cvTemplatesService.findById(dto.templateId);
    }

    const generation = this.cvGenerationRepository.create({
      userId: currentUser.id,
      mode: dto.mode,
      templateId: dto.templateId ?? null,
      status: CvGenerationStatus.PROCESSING,
      cvData: dto.cvData as unknown as Record<string, unknown>,
      style:
        dto.mode === CvGenerationMode.SCRATCH
          ? dto.style?.trim() || 'modern professional'
          : null,
      colorTheme:
        dto.mode === CvGenerationMode.SCRATCH
          ? dto.colorTheme?.trim() || 'clean neutral'
          : null,
      profilePhotoFileId: dto.profilePhotoFileId ?? null,
      generatedImageFileId: null,
      errorMessage: null,
    });

    const savedGeneration = await this.cvGenerationRepository.save(generation);

    void this.processGeneration(savedGeneration.id, currentUser);

    return this.mapGenerationResponse(savedGeneration);
  }

  async findAll(userId: string, page = 1, limit = 10) {
    const normalizedPage = Math.max(1, page);
    const normalizedLimit = Math.min(50, Math.max(1, limit));

    const [generations, totalItems] =
      await this.cvGenerationRepository.findAndCount({
        where: {
          userId,
        },
        order: {
          createdAt: 'DESC',
        },
        skip: (normalizedPage - 1) * normalizedLimit,
        take: normalizedLimit,
      });

    const mappedGenerations = await Promise.all(
      generations.map((generation) => this.mapGenerationResponse(generation)),
    );

    return {
      generations: mappedGenerations,
      pagination: {
        page: normalizedPage,
        limit: normalizedLimit,
        totalItems,
        totalPages:
          totalItems === 0 ? 0 : Math.ceil(totalItems / normalizedLimit),
      },
    };
  }

  async findOne(generationId: string, userId: string) {
    const generation = await this.findOwnedGeneration(generationId, userId);

    return this.mapGenerationResponse(generation);
  }

  async regenerate(generationId: string, currentUser: FileRequestUser) {
    const originalGeneration = await this.findOwnedGeneration(
      generationId,
      currentUser.id,
    );

    if (originalGeneration.profilePhotoFileId) {
      await this.assertOwnedProfilePhoto(
        originalGeneration.profilePhotoFileId,
        currentUser.id,
      );
    }

    if (
      originalGeneration.mode === CvGenerationMode.TEMPLATE &&
      originalGeneration.templateId
    ) {
      await this.cvTemplatesService.findById(originalGeneration.templateId);
    }

    const newGeneration = this.cvGenerationRepository.create({
      userId: originalGeneration.userId,
      mode: originalGeneration.mode,
      templateId: originalGeneration.templateId,
      status: CvGenerationStatus.PROCESSING,
      cvData: originalGeneration.cvData,
      style: originalGeneration.style,
      colorTheme: originalGeneration.colorTheme,
      profilePhotoFileId: originalGeneration.profilePhotoFileId,
      generatedImageFileId: null,
      errorMessage: null,
    });

    const savedGeneration =
      await this.cvGenerationRepository.save(newGeneration);

    void this.processGeneration(savedGeneration.id, currentUser);

    return this.mapGenerationResponse(savedGeneration);
  }

  async delete(generationId: string, currentUser: FileRequestUser) {
    const generation = await this.findOwnedGeneration(
      generationId,
      currentUser.id,
    );

    if (generation.generatedImageFileId) {
      try {
        await this.filesService.archiveFile(
          generation.generatedImageFileId,
          currentUser,
        );
      } catch (error) {
        this.logger.warn(
          `Generated CV file could not be archived for generation ${generation.id}.`,
        );
      }
    }

    await this.cvGenerationRepository.remove(generation);

    return {
      message: 'CV generation deleted successfully.',
      generationId,
    };
  }

  private async processGeneration(
    generationId: string,
    currentUser: FileRequestUser,
  ): Promise<void> {
    const generation = await this.cvGenerationRepository.findOne({
      where: {
        id: generationId,
      },
    });

    if (!generation) {
      return;
    }

    try {
      const cvData = generation.cvData as unknown as CvDataDto;

      const profilePhotoUrl = generation.profilePhotoFileId
        ? await this.getOwnedProfilePhotoSignedUrl(
            generation.profilePhotoFileId,
            generation.userId,
          )
        : null;

      let generatedImageBuffer: Buffer;

      if (generation.mode === CvGenerationMode.TEMPLATE) {
        if (!generation.templateId) {
          throw new BadRequestException(
            'A template ID is required for template generation.',
          );
        }

        const template = await this.cvTemplatesService.findById(
          generation.templateId,
        );

        const prompt = this.cvPromptService.buildTemplatePrompt(
          cvData,
          Boolean(profilePhotoUrl),
        );

        const references: CvReferenceImage[] = [
          {
            url: template.imageUrl,
            fileName: 'cv-template-reference',
          },
        ];

        if (profilePhotoUrl) {
          references.push({
            url: profilePhotoUrl,
            fileName: 'candidate-profile-photo',
          });
        }

        generatedImageBuffer =
          await this.cvImageGenerationService.generateFromReferences(
            prompt,
            references,
          );
      } else {
        const prompt = this.cvPromptService.buildScratchPrompt({
          cvData,
          style: generation.style,
          colorTheme: generation.colorTheme,
          hasProfilePhoto: Boolean(profilePhotoUrl),
        });

        if (profilePhotoUrl) {
          generatedImageBuffer =
            await this.cvImageGenerationService.generateFromReferences(prompt, [
              {
                url: profilePhotoUrl,
                fileName: 'candidate-profile-photo',
              },
            ]);
        } else {
          generatedImageBuffer =
            await this.cvImageGenerationService.generateFromScratch(prompt);
        }
      }

      const uploadedFile = await this.filesService.createFileFromBuffer(
        generatedImageBuffer,
        `generated-cv-${generation.id}.jpg`,
        'image/jpeg',
        currentUser,
        FilePurpose.CV_GENERATED_IMAGE,
      );

      generation.generatedImageFileId = uploadedFile.file.id;

      generation.status = CvGenerationStatus.COMPLETED;

      generation.errorMessage = null;

      await this.cvGenerationRepository.save(generation);
    } catch (error) {
      generation.status = CvGenerationStatus.FAILED;
      generation.errorMessage = this.getSafeGenerationError(error);

      await this.cvGenerationRepository.save(generation);

      const logMessage =
        error instanceof Error ? error.message : 'Unknown generation error';

      this.logger.error(`CV generation ${generation.id} failed: ${logMessage}`);
    }
  }

  private validateMode(dto: CreateCvGenerationDto): void {
    if (dto.mode === CvGenerationMode.TEMPLATE && !dto.templateId) {
      throw new BadRequestException(
        'templateId is required when mode is template.',
      );
    }

    if (dto.mode === CvGenerationMode.SCRATCH && dto.templateId) {
      throw new BadRequestException(
        'templateId must not be provided when mode is scratch.',
      );
    }
  }

  private async findOwnedGeneration(
    generationId: string,
    userId: string,
  ): Promise<CvGeneration> {
    const generation = await this.cvGenerationRepository.findOne({
      where: {
        id: generationId,
        userId,
      },
    });

    if (!generation) {
      throw new NotFoundException('CV generation not found.');
    }

    return generation;
  }

  private async assertOwnedProfilePhoto(
    fileId: string,
    userId: string,
  ): Promise<void> {
    const file = await this.filesService.findActiveFileById(fileId);

    if (file.ownerUserId !== userId) {
      throw new ForbiddenException('You cannot use this profile photo.');
    }

    if (!file.mimeType.startsWith('image/')) {
      throw new BadRequestException(
        'The selected profile photo is not an image.',
      );
    }

    if (file.filePurpose !== FilePurpose.CV_PHOTO) {
      throw new BadRequestException(
        'The selected file was not uploaded as a CV photo.',
      );
    }
  }

  private async getOwnedProfilePhotoSignedUrl(
    fileId: string,
    userId: string,
  ): Promise<string> {
    await this.assertOwnedProfilePhoto(fileId, userId);

    const response = await this.filesService.createSignedReadUrl(fileId);

    return response.signedReadUrl;
  }

  private async mapGenerationResponse(generation: CvGeneration) {
    let generatedImageUrl: string | null = null;

    if (
      generation.status === CvGenerationStatus.COMPLETED &&
      generation.generatedImageFileId
    ) {
      try {
        const signedReadResponse = await this.filesService.createSignedReadUrl(
          generation.generatedImageFileId,
        );

        generatedImageUrl = signedReadResponse.signedReadUrl;
      } catch {
        generatedImageUrl = null;
      }
    }

    return {
      id: generation.id,
      mode: generation.mode,
      templateId: generation.templateId,
      status: generation.status,
      cvData: generation.cvData,
      style: generation.style,
      colorTheme: generation.colorTheme,
      profilePhotoFileId: generation.profilePhotoFileId,
      generatedImageFileId: generation.generatedImageFileId,
      generatedImageUrl,
      errorMessage: generation.errorMessage,
      createdAt: generation.createdAt,
      updatedAt: generation.updatedAt,
    };
  }

  private getSafeGenerationError(error: unknown): string {
    if (error instanceof HttpException) {
      const response = error.getResponse();

      if (typeof response === 'string') {
        return response.slice(0, 500);
      }

      if (response && typeof response === 'object' && 'message' in response) {
        const message = (
          response as {
            message?: string | string[];
          }
        ).message;

        if (Array.isArray(message)) {
          return message.join(', ').slice(0, 500);
        }

        if (typeof message === 'string') {
          return message.slice(0, 500);
        }
      }
    }

    return 'The CV image could not be generated. Please try again.';
  }
}
