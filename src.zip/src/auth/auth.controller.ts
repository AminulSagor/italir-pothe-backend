import {
  Body,
  Controller,
  HttpCode,
  HttpStatus,
  Post,
  Req,
  UnauthorizedException,
  UseGuards,
} from '@nestjs/common';

import type { AuthenticatedRequest } from '../common/interfaces/authenticated-request.interface';

import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';

import { AuthService } from './auth.service';

import {
  CreateAdminDto,
  ForgotPasswordDto,
  LoginDto,
  LinkSocialAccountDto,
  ResendOtpDto,
  ResetPasswordDto,
  SignupDto,
  SocialLoginDto,
  VerifyOtpDto,
  VerifyPasswordResetOtpDto,
} from './dto/auth.dto';

interface AuthenticatedSession {
  userId: string;
  sessionId: string;
  deviceId: string;
}

@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Post('signup')
  async signup(
    @Body() signupDto: SignupDto,
    @Req() request: AuthenticatedRequest,
  ) {
    return this.authService.signup(signupDto, request.ip);
  }

  @Post('admin/create')
  async createAdmin(@Body() createAdminDto: CreateAdminDto) {
    return this.authService.createAdmin(createAdminDto);
  }

  @Post('login')
  @HttpCode(HttpStatus.OK)
  async login(@Body() loginDto: LoginDto) {
    return this.authService.login(loginDto);
  }

  @Post('social/google')
  @HttpCode(HttpStatus.OK)
  socialGoogle(@Body() dto: SocialLoginDto) {
    return this.authService.socialLogin('google', dto);
  }

  @Post('social/facebook')
  @HttpCode(HttpStatus.OK)
  socialFacebook(@Body() dto: SocialLoginDto) {
    return this.authService.socialLogin('facebook', dto);
  }

  @Post('social/apple')
  @HttpCode(HttpStatus.OK)
  socialApple(@Body() dto: SocialLoginDto) {
    return this.authService.socialLogin('apple', dto);
  }

  @Post('social/google/link')
  @UseGuards(JwtAuthGuard)
  @HttpCode(HttpStatus.OK)
  linkGoogle(
    @Req() request: AuthenticatedRequest,
    @Body() dto: LinkSocialAccountDto,
  ) {
    return this.authService.linkSocialAccount(
      this.getAuthenticatedUserId(request),
      'google',
      dto,
    );
  }

  @Post('social/facebook/link')
  @UseGuards(JwtAuthGuard)
  @HttpCode(HttpStatus.OK)
  linkFacebook(
    @Req() request: AuthenticatedRequest,
    @Body() dto: LinkSocialAccountDto,
  ) {
    return this.authService.linkSocialAccount(
      this.getAuthenticatedUserId(request),
      'facebook',
      dto,
    );
  }

  @Post('social/apple/link')
  @UseGuards(JwtAuthGuard)
  @HttpCode(HttpStatus.OK)
  linkApple(
    @Req() request: AuthenticatedRequest,
    @Body() dto: LinkSocialAccountDto,
  ) {
    return this.authService.linkSocialAccount(
      this.getAuthenticatedUserId(request),
      'apple',
      dto,
    );
  }

  @Post('verify-otp')
  @HttpCode(HttpStatus.OK)
  async verifyOtp(
    @Body() verifyOtpDto: VerifyOtpDto,
    @Req() request: AuthenticatedRequest,
  ) {
    return this.authService.verifyOtp(verifyOtpDto, request.ip);
  }

  @Post('resend-otp')
  @HttpCode(HttpStatus.OK)
  async resendOtp(
    @Body() resendOtpDto: ResendOtpDto,
    @Req() request: AuthenticatedRequest,
  ) {
    return this.authService.resendSignupOtp(resendOtpDto, request.ip);
  }

  @Post('forgot-password')
  @HttpCode(HttpStatus.OK)
  async forgotPassword(
    @Body() forgotPasswordDto: ForgotPasswordDto,
    @Req() request: AuthenticatedRequest,
  ) {
    return this.authService.requestPasswordReset(forgotPasswordDto, request.ip);
  }

  @Post('verify-reset-otp')
  @HttpCode(HttpStatus.OK)
  async verifyResetOtp(
    @Body()
    verifyDto: VerifyPasswordResetOtpDto,
    @Req() request: AuthenticatedRequest,
  ) {
    return this.authService.verifyPasswordResetOtp(verifyDto, request.ip);
  }

  @Post('reset-password')
  @HttpCode(HttpStatus.OK)
  async resetPassword(@Body() resetPasswordDto: ResetPasswordDto) {
    return this.authService.resetPassword(resetPasswordDto);
  }

  @Post('logout')
  @UseGuards(JwtAuthGuard)
  @HttpCode(HttpStatus.OK)
  async logout(@Req() request: AuthenticatedRequest) {
    const session = this.getAuthenticatedSession(request);

    return this.authService.logout(
      session.userId,
      session.sessionId,
      session.deviceId,
    );
  }

  private getAuthenticatedSession(
    request: AuthenticatedRequest,
  ): AuthenticatedSession {
    const userId = request.user?.id ?? request.user?.sub;

    const sessionId = request.user?.sessionId;

    const deviceId = request.user?.deviceId;

    if (!userId) {
      throw new UnauthorizedException('Authenticated user not found');
    }

    if (!sessionId || !deviceId) {
      throw new UnauthorizedException('Authentication session not found');
    }

    return {
      userId,
      sessionId,
      deviceId,
    };
  }

  private getAuthenticatedUserId(request: AuthenticatedRequest): string {
    const userId = request.user?.id ?? request.user?.sub;
    if (!userId) {
      throw new UnauthorizedException('Authenticated user not found');
    }
    return userId;
  }
}
